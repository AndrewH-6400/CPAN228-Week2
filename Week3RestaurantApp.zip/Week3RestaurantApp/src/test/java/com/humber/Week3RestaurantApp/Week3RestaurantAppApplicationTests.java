package com.humber.Week3RestaurantApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week3RestaurantAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
